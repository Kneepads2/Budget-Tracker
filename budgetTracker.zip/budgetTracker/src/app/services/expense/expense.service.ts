import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExpenseService {

  private API_URL = "http://localhost:8080/api"; // Ensure the API URL matches your server route

  constructor(private http: HttpClient) { }

  getAllExpenses(): Observable<any> {
    return this.http.get(`${this.API_URL}/expense`);
  }

  postExpense(expense: any): Observable<any> {
    return this.http.post(`${this.API_URL}/expense`, expense);
  }

  deleteExpense(id: number): Observable<any> {
    return this.http.delete(`${this.API_URL}/expense/${id}`);
  }

  getExpenseById(id: number): Observable<any> {
    return this.http.get<any>(`${this.API_URL}/expense/${id}`);
  }

  updateExpense(id: number, expense: any): Observable<any> {
    return this.http.put<any>(`${this.API_URL}/expense/${id}`, expense);
  }
}
