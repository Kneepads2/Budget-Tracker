import { Injectable } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {Router} from "@angular/router";
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class StatsService {

  private API_URL = "http://localhost:8080/";
  constructor(private http: HttpClient,
              private router: Router) { }

  getStats(): Observable<any>{
    return this.http.get(this.API_URL + "api/stats");
  }

  getChart(): Observable<any>{
    return this.http.get(this.API_URL + "api/stats/chart");
  }
}
