import {Component, ElementRef, ViewChild} from '@angular/core';
import {StatsService} from "../../services/stats/stats.service";
import Chart from 'chart.js/auto';
import {CategoryScale} from 'chart.js'

Chart.register(CategoryScale);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {

  stats: any;
  expenses: any;
  incomes: any;
  gridStyle = {
    width: '25%',
    textAlign: 'center'
  };

  @ViewChild('incomeLineChartRef') private incomeLineChartRef:ElementRef;
  @ViewChild('expenseLineChartRef') private expenseLineChartRef:ElementRef;

  constructor(private statService: StatsService) {
    this.getStats();
    this.getChartData();
  }

  createLineChart(){
    const incomeCtx = this.incomeLineChartRef.nativeElement.getContext('2d');
    new Chart(incomeCtx, {
      type: 'doughnut',
      data: {
        labels: this.incomes.map(income => income.category),
        datasets: [{
          label: 'Income',
          data: this.incomes.map(income => income.amount),
          borderWidth: 1,
          backgroundColor: [
            'rgb(28,218,91)', //bank
            'rgb(237,236,233)', //freelance
            'rgb(107,216,28)', //investments
            'rgb(22,181,218)', //refunds
            'rgb(221,77,30)', //rental income
            'rgb(34,61,228)', //salary
            'rgb(189,30,88)', //sales
            'rgb(63,65,73)' //other
          ],
          borderColor: 'rgb(0,0,0)'
        }]
      },
      /*options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
      * */
    });

    const expenseCtx = this.expenseLineChartRef.nativeElement.getContext('2d');
    new Chart(expenseCtx, {
      type: 'doughnut',
      data: {
        labels: this.expenses.map(expense => expense.category),
        datasets: [{
          label: 'Expense',
          data: this.expenses.map(expense => expense.amount),
          borderWidth: 1,
          backgroundColor: [
            'rgb(90,83,83)', //bills
            'rgb(218,15,214)', //clothing
            'rgb(200,134,10)', //education
            'rgb(234,223,11)', //entertainment
            'rgb(29,225,144)', //food
            'rgb(209,14,18)', //health
            'rgb(31,94,198)', //home
            'rgb(99,58,17)', //rent
            'rgb(39,9,232)', //subscription
            'rgb(13,213,8)', //taxes
            'rgb(34,198,198)', //transportation
            'rgb(75,21,142)',], //other
          borderColor: 'rgb(0,0,0)',
          hoverOffset: 4
        }]
      },
      /*options: {
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }*/
    });
  }

  getStats() {
    this.statService.getStats().subscribe(res => {
      console.log(res);
      this.stats = res;
    });
  }

  getChartData(){
    this.statService.getChart().subscribe(res =>{
      if(res.expenseList != null && res.incomeList != null){
        this.incomes = res.incomeList;
        this.expenses = res.expenseList;
        console.log(res);
        this.createLineChart();
      }
    })
  }
}
