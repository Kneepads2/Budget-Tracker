import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { StatsService } from "../../services/stats/stats.service";
import Chart from 'chart.js/auto';
import { CategoryScale } from 'chart.js';

Chart.register(CategoryScale);

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements AfterViewInit {

  stats: any;
  expenses: any;
  incomes: any;
  aggregatedIncomes: any;
  aggregatedExpenses: any;
  gridStyle = {
    width: '25%',
    textAlign: 'center'
  };

  @ViewChild('incomeLineChartRef') private incomeLineChartRef: ElementRef;
  @ViewChild('expenseLineChartRef') private expenseLineChartRef: ElementRef;

  ngAfterViewInit() {
    this.getStats();
    this.getChartData();
  }

  constructor(private statService: StatsService) { }

  createLineChart() {
    const incomeCtx = this.incomeLineChartRef.nativeElement.getContext('2d');
    new Chart(incomeCtx, {
      type: 'doughnut',
      data: {
        labels: this.aggregatedIncomes.map(income => income.category),
        datasets: [{
          label: 'Income',
          data: this.aggregatedIncomes.map(income => income.amount),
          borderWidth: 1,
          backgroundColor: [
            'rgb(28,218,91)', 'rgb(237,236,233)', 'rgb(107,216,28)',
            'rgb(22,181,218)', 'rgb(221,77,30)', 'rgb(34,61,228)',
            'rgb(189,30,88)', 'rgb(63,65,73)'
          ],
          borderColor: 'rgb(0,0,0)'
        }]
      }
    });

    const expenseCtx = this.expenseLineChartRef.nativeElement.getContext('2d');
    new Chart(expenseCtx, {
      type: 'doughnut',
      data: {
        labels: this.aggregatedExpenses.map(expense => expense.category),
        datasets: [{
          label: 'Expense',
          data: this.aggregatedExpenses.map(expense => expense.amount),
          borderWidth: 1,
          backgroundColor: [
            'rgb(90,83,83)', 'rgb(218,15,214)', 'rgb(200,134,10)',
            'rgb(234,223,11)', 'rgb(29,225,144)', 'rgb(209,14,18)',
            'rgb(31,94,198)', 'rgb(99,58,17)', 'rgb(39,9,232)',
            'rgb(13,213,8)', 'rgb(34,198,198)', 'rgb(75,21,142)'
          ],
          borderColor: 'rgb(0,0,0)',
          hoverOffset: 4
        }]
      }
    });
  }

  getStats() {
    this.statService.getStats().subscribe(res => {
      console.log(res);
      this.stats = res;
    });
  }

  getChartData() {
    this.statService.getChart().subscribe(res => {
      if (res.expenseList != null && res.incomeList != null) {
        this.incomes = res.incomeList;
        this.expenses = res.expenseList;
        this.aggregatedIncomes = this.aggregateByCategory(this.incomes);
        this.aggregatedExpenses = this.aggregateByCategory(this.expenses);
        console.log('Aggregated Incomes:', this.aggregatedIncomes);
        console.log('Aggregated Expenses:', this.aggregatedExpenses);
        this.createLineChart();
      }
    });
  }

  aggregateByCategory(data) {
    const aggregated = [];
    const map = new Map();
    for (const item of data) {
      if (!map.has(item.category)) {
        map.set(item.category, { category: item.category, amount: 0 });
        aggregated.push(map.get(item.category));
      }
      map.get(item.category).amount += parseFloat(item.amount);
    }
    return aggregated;
  }

}
