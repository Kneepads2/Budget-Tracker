import {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService
} from "./chunk-F2QIQTWY.js";
import "./chunk-4SWRDNWC.js";
import "./chunk-RQL545KO.js";
import "./chunk-B7T4TYD4.js";
import "./chunk-U2ET4FHF.js";
import "./chunk-Q2N6ZQSQ.js";
import "./chunk-UYKBX2H7.js";
import "./chunk-OP5GNS3D.js";
import "./chunk-J4B6MK7R.js";
export {
  DEFAULT_TWOTONE_COLOR,
  NZ_ICONS,
  NZ_ICONS_PATCH,
  NZ_ICONS_USED_BY_ZORRO,
  NZ_ICON_DEFAULT_TWOTONE_COLOR,
  NzIconDirective,
  NzIconModule,
  NzIconPatchService,
  NzIconService
};
//# sourceMappingURL=ng-zorro-antd_icon.js.map
