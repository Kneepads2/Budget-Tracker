import {
  NzTransitionPatchDirective,
  NzTransitionPatchModule
} from "./chunk-N2ERUWYK.js";
import "./chunk-OP5GNS3D.js";
import "./chunk-J4B6MK7R.js";
export {
  NzTransitionPatchDirective as ɵNzTransitionPatchDirective,
  NzTransitionPatchModule as ɵNzTransitionPatchModule
};
//# sourceMappingURL=ng-zorro-antd_core_transition-patch.js.map
