import {
  NZ_EMPTY_COMPONENT_NAME,
  NzEmbedEmptyComponent,
  NzEmptyComponent,
  NzEmptyDefaultComponent,
  NzEmptyModule,
  NzEmptySimpleComponent
} from "./chunk-KNK3JJTG.js";
import "./chunk-UGL7YLUP.js";
import "./chunk-C2PFEFTV.js";
import "./chunk-DHQHAZQV.js";
import "./chunk-E624PMJQ.js";
import "./chunk-RQL545KO.js";
import "./chunk-B7T4TYD4.js";
import "./chunk-UYKBX2H7.js";
import "./chunk-OP5GNS3D.js";
import "./chunk-J4B6MK7R.js";
export {
  NZ_EMPTY_COMPONENT_NAME,
  NzEmbedEmptyComponent,
  NzEmptyComponent,
  NzEmptyDefaultComponent,
  NzEmptyModule,
  NzEmptySimpleComponent
};
//# sourceMappingURL=ng-zorro-antd_empty.js.map
