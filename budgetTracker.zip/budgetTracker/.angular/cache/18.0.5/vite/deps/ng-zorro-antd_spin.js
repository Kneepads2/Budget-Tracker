import {
  NzSpinComponent,
  NzSpinModule
} from "./chunk-Z6GZ57AA.js";
import "./chunk-AOIZ4QBU.js";
import "./chunk-RQL545KO.js";
import "./chunk-B7T4TYD4.js";
import "./chunk-UYKBX2H7.js";
import "./chunk-OP5GNS3D.js";
import "./chunk-J4B6MK7R.js";
export {
  NzSpinComponent,
  NzSpinModule
};
//# sourceMappingURL=ng-zorro-antd_spin.js.map
