import {
  NzAvatarComponent,
  NzAvatarGroupComponent,
  NzAvatarModule
} from "./chunk-27XIWPDD.js";
import "./chunk-F2QIQTWY.js";
import "./chunk-4SWRDNWC.js";
import "./chunk-RQL545KO.js";
import "./chunk-B7T4TYD4.js";
import "./chunk-U2ET4FHF.js";
import "./chunk-Q2N6ZQSQ.js";
import "./chunk-UYKBX2H7.js";
import "./chunk-OP5GNS3D.js";
import "./chunk-J4B6MK7R.js";
export {
  NzAvatarComponent,
  NzAvatarGroupComponent,
  NzAvatarModule
};
//# sourceMappingURL=ng-zorro-antd_avatar.js.map
