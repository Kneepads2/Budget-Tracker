import {
  NzSkeletonComponent,
  NzSkeletonElementAvatarComponent,
  NzSkeletonElementButtonComponent,
  NzSkeletonElementDirective,
  NzSkeletonElementImageComponent,
  NzSkeletonElementInputComponent,
  NzSkeletonModule
} from "./chunk-37MCV73N.js";
import "./chunk-B7T4TYD4.js";
import "./chunk-UYKBX2H7.js";
import "./chunk-OP5GNS3D.js";
import "./chunk-J4B6MK7R.js";
export {
  NzSkeletonComponent,
  NzSkeletonElementAvatarComponent,
  NzSkeletonElementButtonComponent,
  NzSkeletonElementDirective,
  NzSkeletonElementImageComponent,
  NzSkeletonElementInputComponent,
  NzSkeletonModule
};
//# sourceMappingURL=ng-zorro-antd_skeleton.js.map
