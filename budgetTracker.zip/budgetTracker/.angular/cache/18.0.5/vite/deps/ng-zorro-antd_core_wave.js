import {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
} from "./chunk-U6SF4K66.js";
import "./chunk-H3FJLVFZ.js";
import "./chunk-JVRLZ4RT.js";
import "./chunk-UJDMKQ4M.js";
import "./chunk-4SWRDNWC.js";
import "./chunk-U2ET4FHF.js";
import "./chunk-Q2N6ZQSQ.js";
import "./chunk-UYKBX2H7.js";
import "./chunk-OP5GNS3D.js";
import "./chunk-J4B6MK7R.js";
export {
  NZ_WAVE_GLOBAL_CONFIG,
  NZ_WAVE_GLOBAL_DEFAULT_CONFIG,
  NzWaveDirective,
  NzWaveModule,
  NzWaveRenderer,
  provideNzWave
};
//# sourceMappingURL=ng-zorro-antd_core_wave.js.map
